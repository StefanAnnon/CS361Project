public class Account
{
    public string username, email;
    public string password = "";
    public int currency;

    public Account(string username, string email, string password)
    {
        this.username = username;
        this.email = email;
        this.password = password;
        this.currency = 1000;
    }
}
