public enum Menu
{
   START,
   LOGIN,
   REGISTER,
   MAIN,
   SHOP
}
