using UnityEngine;

public class AccountManager : MonoBehaviour
{
    public static AccountManager instance { get; private set; }
    public Account account;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
            DestroyImmediate(gameObject);
    }
}
