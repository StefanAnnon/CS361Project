using UnityEngine;

public static class MenuManager
{
    public static bool IsInitialized { get; private set; }
    public static GameObject startMenu, loginMenu, registerMenu, mainMenu, shopMenu;

    public static void Init()
    {
        GameObject canvas = GameObject.Find("Canvas");
        startMenu = canvas.transform.Find("Start").gameObject;
        loginMenu = canvas.transform.Find("Login").gameObject;
        registerMenu = canvas.transform.Find("Register").gameObject;
        mainMenu = canvas.transform.Find("Main").gameObject;
        shopMenu = canvas.transform.Find("Shop").gameObject;

        IsInitialized = true;
    }

    public static void OpenMenu(Menu menu, GameObject callingMenu)
    {
        if (!IsInitialized)
            Init();

        switch (menu)
        {
            case Menu.START:
                startMenu.SetActive(true);
                break;
            case Menu.LOGIN:
                loginMenu.SetActive(true);
                break;
            case Menu.REGISTER:
                registerMenu.SetActive(true);
                break;
            case Menu.MAIN:
                mainMenu.SetActive(true);
                break;
            case Menu.SHOP:
                shopMenu.SetActive(true);
                break;
        }

        callingMenu.SetActive(false);
    }
}
