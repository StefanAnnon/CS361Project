using UnityEngine;
using TMPro;
using System.IO;

public class ShopMenu : MonoBehaviour
{
    public TMP_Text currencyField;
    public GameObject sniper;
    public GameObject haxxor;

    private int price;

    public void Awake()
    {
        currencyField.text = AccountManager.instance.account.currency.ToString();
    }

    public void On_Click_Main()
    {
        MenuManager.OpenMenu(Menu.MAIN, gameObject);
    }

    public void On_Click_Sniper()
    {
        sniper.SetActive(true);
        haxxor.SetActive(false);
        price = 500;
    }

    public void On_Click_Haxxor()
    {
        sniper.SetActive(false);
        haxxor.SetActive(true);
        price = 100;
    }

    public void On_Click_Buy()
    {
        Account account = AccountManager.instance.account;

        if (account.currency >= price)
        {
            account.currency -= price;
            currencyField.text = account.currency.ToString();

            string json = JsonUtility.ToJson(account);
            using StreamWriter writer = new StreamWriter("../CS361 Unity Project/Assets/_MAIN/account.txt");
            writer.Write(json);
        }

    }
}
