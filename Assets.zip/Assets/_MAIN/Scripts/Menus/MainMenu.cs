using UnityEngine;
using TMPro;

public class MainMenu : MonoBehaviour
{
    public TMP_Text usernameField;
    public TMP_Text currencyField;

    public void Awake()
    {
        usernameField.text = AccountManager.instance.account.username;
        currencyField.text = AccountManager.instance.account.currency.ToString();
    }

    public void OnEnable()
    {
        currencyField.text = AccountManager.instance.account.currency.ToString();
    }

    public void OnClick_Shop()
    {
        MenuManager.OpenMenu(Menu.SHOP, gameObject);
    }
}
