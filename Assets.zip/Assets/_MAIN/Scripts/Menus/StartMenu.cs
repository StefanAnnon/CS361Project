using UnityEngine;

public class StartMenu : MonoBehaviour
{
    public void OnClick_Login()
    {
        MenuManager.OpenMenu(Menu.LOGIN, gameObject);
    }
}
