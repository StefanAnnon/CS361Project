using System.IO;
using UnityEngine;
using TMPro;
using System.Security.Cryptography;
using System;

public class LoginMenu : MonoBehaviour
{
    private string email = "";
    private string password = "";
    private bool checkOn = false;

    public TMP_InputField passwordField;
    public TMP_InputField emailField;
    public TMP_Text errorField;
    public GameObject check;

    public void OnClick_Start()
    {
        MenuManager.OpenMenu(Menu.START, gameObject);
    }

    public void OnClick_Register()
    {
        MenuManager.OpenMenu(Menu.REGISTER, gameObject);
    }

    public void OnClick_Check()
    {
        checkOn = !checkOn;
        check.SetActive(checkOn);
    }

    public void OnClick_Main()
    {
        email = emailField.text;
        password = passwordField.text;

        using StreamReader reader = new StreamReader("../CS361 Unity Project/Assets/_MAIN/account.txt");
        string json = reader.ReadToEnd();
        Account account = JsonUtility.FromJson<Account>(json);

        var sha1 = new SHA1CryptoServiceProvider();
        byte[] bytes = System.Text.Encoding.ASCII.GetBytes(password);
        byte[] byteHash = sha1.ComputeHash(bytes);
        string hashedPassword = Convert.ToBase64String(byteHash);

        if (account.email == email && account.password == hashedPassword)
        {
            AccountManager.instance.account = account;
            MenuManager.OpenMenu(Menu.MAIN, gameObject);
        }
        else
            errorField.text = "Email and password do not match";

    }
}
