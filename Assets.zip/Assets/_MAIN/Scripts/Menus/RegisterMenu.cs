using UnityEngine;
using TMPro;
using System.IO;
using System.Security.Cryptography;
using System;

public class RegisterMenu : MonoBehaviour
{
    public TMP_InputField emailField;
    public TMP_InputField passwordField;
    public TMP_InputField usernameField;
    public TMP_InputField confirmPassField;
    public TMP_Text errorField;

    public void OnClick_Start()
    {
        MenuManager.OpenMenu(Menu.START, gameObject);
    }

    public void OnClick_Login()
    {
        MenuManager.OpenMenu(Menu.LOGIN, gameObject);
    }

    public void OnClick_Main()
    {
        string email = emailField.text;
        string password = passwordField.text;
        string username = usernameField.text;
        string confirmPassword = confirmPassField.text;

        var sha1 = new SHA1CryptoServiceProvider();
        byte[] bytes = System.Text.Encoding.ASCII.GetBytes(password);
        byte[] byteHash = sha1.ComputeHash(bytes);
        string hashedPassword = Convert.ToBase64String(byteHash);

        if (username == "")
            errorField.text = "Please enter a username";
        else if (email == "")
            errorField.text = "Please enter an email";
        else if (password == "")
            errorField.text = "Please enter a password";
        else if (confirmPassword == "")
            errorField.text = "Please confirm your password";
        else if (password != confirmPassword)
            errorField.text = "Passwords do not match";
        else
        {
            Account newAccount = new Account(username, email, hashedPassword);

            string json = JsonUtility.ToJson(newAccount);

            using StreamWriter writer = new StreamWriter("../CS361 Unity Project/Assets/_MAIN/account.txt");
            writer.Write(json);
            AccountManager.instance.account = newAccount;
            MenuManager.OpenMenu(Menu.MAIN, gameObject);
        }


    }
}
