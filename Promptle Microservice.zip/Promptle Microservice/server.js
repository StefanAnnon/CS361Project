'use strict';

const express = require("express");
const app = express();
const PORT = 3000;

app.use(express.json());

app.post("/", (req, res) => {
    let prompt = req.body.prompt;
    let guess = req.body.user_guess;
    let matches = {"indexes":[]};
    
    for (let i = 0; i<prompt.length; i++){
        if (prompt[i].toLowerCase().replace(/[^a-z]/g, '') === guess.toLowerCase().replace(/[^a-z]/g, '')){
            matches.indexes.push(i)
        }
    }
    res.json(matches);
});

app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}...`);
});